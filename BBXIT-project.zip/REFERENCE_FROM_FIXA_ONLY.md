# Referensi APK FIXA ONLY

File sumber diperiksa: `FIXA ONLY VIP-strenc-protected-v3(1).apk`

## Materi yang dimasukkan ke proyek BBX!T
- Dokumen lisensi/NOTICE teks yang ikut dibundel APK: APACHE-2.0.txt, BOUNCY-CASTLE-LICENSE.txt, NOTICE.txt
- `localConfig.template.json`: template konfigurasi baru yang kosong dan dapat diedit; bukan salinan blob terenkripsi.

## Materi yang tidak disalin
- `auth.txt`, `ffrtc_log.txt`, `xyz.guard`, `OnDevzGuard`, file `p`/`k`: data terenkripsi, autentikasi, log, atau proteksi.
- `classes.dex`, `Assembly-CSharp-patch.bytes`, dan library `.so`: kode/binary aplikasi pihak ketiga.
- Logo dan resource bermerek: tidak disalin tanpa izin pemilik.

BBX!T tetap proyek Android mandiri. Lisensi pihak ketiga disertakan sebagai referensi; periksa ketentuan masing-masing sebelum memakai komponen terkait.
