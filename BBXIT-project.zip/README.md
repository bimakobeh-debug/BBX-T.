# BBX!T

Proyek Android dasar independen untuk aplikasi pengelola konfigurasi lokal.

## Build APK lewat GitHub Actions
1. Upload seluruh isi folder proyek ini ke repository GitHub baru.
2. Buka tab **Actions**.
3. Pilih **Build BBX!T APK**.
4. Tekan **Run workflow** jika workflow belum berjalan otomatis.
5. Setelah selesai, buka hasil run dan unduh artifact **BBXIT-debug-apk**.
6. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

Aplikasi ini adalah kerangka dasar. Belum membaca atau mengubah data game dan tidak menyertakan kode, lisensi, autentikasi, atau proteksi dari aplikasi pihak ketiga.
